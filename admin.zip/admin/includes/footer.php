<div class="footer-wrap pd-20 mb-20 card-box">
				NUST Programming Competition
			</div>